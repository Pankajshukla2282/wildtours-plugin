<?php

declare(strict_types=1);

namespace PWT\PostTypes;

defined('ABSPATH') || exit;

/**
 * Restaurant / dining partner content type.
 */
final class Restaurant extends PostType
{
    protected string $postType = 'pwt_restaurant';
    protected string $singular = 'Restaurant';
    protected string $plural = 'Restaurants';
    protected string $menuIcon = 'dashicons-carrot';
    protected array $supports = ['title', 'editor', 'thumbnail', 'excerpt'];
    protected array $taxonomies = ['pwt_cuisine'];
    protected ?string $rewriteSlug = 'restaurants';
}
