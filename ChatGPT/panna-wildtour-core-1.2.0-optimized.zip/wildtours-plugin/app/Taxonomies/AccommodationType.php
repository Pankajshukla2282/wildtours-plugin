<?php

declare(strict_types=1);

namespace PWT\Taxonomies;

defined('ABSPATH') || exit;

/** Accommodation classification for the existing Resort CPT. */
final class AccommodationType extends Taxonomy
{
    protected string $taxonomy = 'pwt_accommodation_type';
    protected string $singular = 'Accommodation Type';
    protected string $plural = 'Accommodation Types';
    protected array $postTypes = ['pwt_resort'];
    protected ?string $rewriteSlug = 'accommodation-type';
}
