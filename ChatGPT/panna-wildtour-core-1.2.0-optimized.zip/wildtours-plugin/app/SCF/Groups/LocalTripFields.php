<?php

declare(strict_types=1);

namespace PWT\SCF\Groups;

defined('ABSPATH') || exit;

use PWT\SCF\FieldGroup;

/** Local trip / excursion field group. */
final class LocalTripFields extends FieldGroup
{
    public function register(): void
    {
        $this->addGroup([
            'key' => 'group_pwt_local_trip_details',
            'title' => __('Local Trip Details', 'wildtours-plugin'),
            'location' => [[[
                'param' => 'post_type',
                'operator' => '=',
                'value' => 'pwt_local_trip',
            ]]],
            'fields' => [
                [
                    'key' => 'field_pwt_local_trip_code',
                    'label' => __('Trip Code', 'wildtours-plugin'),
                    'name' => 'trip_code',
                    'type' => 'text',
                ],
                [
                    'key' => 'field_pwt_local_trip_duration',
                    'label' => __('Duration', 'wildtours-plugin'),
                    'name' => 'duration',
                    'type' => 'text',
                ],
                [
                    'key' => 'field_pwt_local_trip_price',
                    'label' => __('Base Price (INR)', 'wildtours-plugin'),
                    'name' => 'regular_price',
                    'type' => 'number',
                ],
                [
                    'key' => 'field_pwt_local_trip_offer_price',
                    'label' => __('Offer Price (INR)', 'wildtours-plugin'),
                    'name' => 'offer_price',
                    'type' => 'number',
                ],
                [
                    'key' => 'field_pwt_local_trip_group_size',
                    'label' => __('Maximum Group Size', 'wildtours-plugin'),
                    'name' => 'max_group_size',
                    'type' => 'number',
                ],
                [
                    'key' => 'field_pwt_local_trip_difficulty',
                    'label' => __('Difficulty', 'wildtours-plugin'),
                    'name' => 'difficulty',
                    'type' => 'select',
                    'choices' => [
                        'easy' => __('Easy', 'wildtours-plugin'),
                        'moderate' => __('Moderate', 'wildtours-plugin'),
                        'challenging' => __('Challenging', 'wildtours-plugin'),
                    ],
                ],
                [
                    'key' => 'field_pwt_local_trip_pickup',
                    'label' => __('Pickup / Meeting Point', 'wildtours-plugin'),
                    'name' => 'pickup_point',
                    'type' => 'text',
                ],
                [
                    'key' => 'field_pwt_local_trip_inclusions',
                    'label' => __('Inclusions', 'wildtours-plugin'),
                    'name' => 'inclusions',
                    'type' => 'textarea',
                ],
                [
                    'key' => 'field_pwt_local_trip_exclusions',
                    'label' => __('Exclusions', 'wildtours-plugin'),
                    'name' => 'exclusions',
                    'type' => 'textarea',
                ],
                [
                    'key' => 'field_pwt_local_trip_notes',
                    'label' => __('Operational Notes', 'wildtours-plugin'),
                    'name' => 'operational_notes',
                    'type' => 'textarea',
                ],
            ],
        ]);
    }
}
