# Panna Wild Tour Core Architecture

## Ownership

- **Plugin** owns business data and operations: packages, safaris, destinations, accommodations/resorts, vehicles, restaurants, local trips, reviews, FAQs and bookings.
- **Theme** owns presentation: templates, navigation, layout, styling and block patterns.
- **SCF** field groups live in the plugin so content survives a theme change.

## Current catalog

- `pwt_package` — tour packages
- `pwt_safari` — safari products
- `pwt_destination` — destinations
- `pwt_resort` — accommodation/resort inventory (kept for backward compatibility)
- `pwt_vehicle` — vehicles
- `pwt_restaurant` — restaurants/dining partners
- `pwt_local_trip` — local excursions
- `pwt_booking` — internal booking records

## Next scaling stages

1. Add a normalized service/product layer for package, safari, stay, restaurant reservation and local trip booking.
2. Add customers and booking items as first-class domain objects.
3. Move high-volume availability and booking transactions from post meta to dedicated tables when traffic/volume requires it.
4. Add inventory/rate-plan/blackout-date services instead of embedding availability rules in frontend classes.
5. Add capability-specific admin roles and audit logs before multi-staff operation.
6. Keep REST endpoints versioned (`pwt/v1`, then `pwt/v2`) and never expose private booking/customer data through public routes.

## Backward compatibility

Existing `pwt_resort` content is intentionally retained. It can represent hotels, resorts, lodges and homestays through the accommodation taxonomy and fields. A future migration can introduce a dedicated accommodation domain without breaking existing URLs.
