# Panna Wild Tour Core

Business/content plugin for a tour, safari, accommodation, restaurant and local-trip agency.

## Requirements

- WordPress 6.7+
- PHP 8.2+
- Secure Custom Fields (SCF) for field groups

## Version

1.2.0

## Important rule

Do not put business CPTs or field groups in the theme. The theme should consume this plugin's data.
