<?php
declare(strict_types=1);
namespace PWT\Payments;
defined('ABSPATH') || exit;

use PWT\Core\Database\Schema;

final class PaymentRepository
{
    public function create(array $data): int
    {
        global $wpdb;
        $row = [
            'booking_id'=>absint($data['booking_id'] ?? 0),
            'provider'=>sanitize_key((string)($data['provider'] ?? '')),
            'provider_payment_id'=>sanitize_text_field((string)($data['provider_payment_id'] ?? '')) ?: null,
            'amount'=>max(0,(float)($data['amount'] ?? 0)),
            'currency'=>strtoupper(sanitize_text_field((string)($data['currency'] ?? 'INR'))),
            'status'=>sanitize_key((string)($data['status'] ?? 'pending')),
            'transaction_type'=>sanitize_key((string)($data['transaction_type'] ?? 'payment')),
            'idempotency_key'=>sanitize_text_field((string)($data['idempotency_key'] ?? '')) ?: null,
            'gateway_response'=>wp_json_encode($data['gateway_response'] ?? []),
            'paid_at'=>!empty($data['paid_at']) ? sanitize_text_field((string)$data['paid_at']) : null,
            'created_at'=>current_time('mysql'),
            'updated_at'=>current_time('mysql'),
        ];
        $wpdb->insert(Schema::tables()['payments'], $row);
        return (int)$wpdb->insert_id;
    }

    public function byIdempotencyKey(string $key): ?array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM ".Schema::tables()['payments']." WHERE idempotency_key=%s LIMIT 1", $key
        ), ARRAY_A);
        return $row ?: null;
    }

    public function markPaid(int $id, array $gatewayResponse = []): bool
    {
        global $wpdb;
        return false !== $wpdb->update(
            Schema::tables()['payments'],
            ['status'=>'paid','gateway_response'=>wp_json_encode($gatewayResponse),'paid_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],
            ['id'=>$id],
            ['%s','%s','%s','%s'],
            ['%d']
        );
    }
}
