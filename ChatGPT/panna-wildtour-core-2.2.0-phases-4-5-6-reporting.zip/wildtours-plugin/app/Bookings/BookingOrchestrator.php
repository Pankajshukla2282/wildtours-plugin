<?php
declare(strict_types=1);
namespace PWT\Bookings;
defined('ABSPATH') || exit;

use PWT\Availability\AvailabilityRepository;
use PWT\Pricing\PricingService;
use PWT\Core\Database\Schema;
use WP_Error;

final class BookingOrchestrator
{
    public function __construct(
        private readonly BookingRepository $bookings,
        private readonly BookingItemRepository $items,
        private readonly AvailabilityRepository $availability,
        private readonly PricingService $pricing
    ) {}

    public function create(array $request): int|WP_Error
    {
        global $wpdb;

        $customerId = absint($request['customer_id'] ?? 0);
        $currency = strtoupper(sanitize_text_field((string)($request['currency'] ?? 'INR')));
        $items = is_array($request['items'] ?? null) ? $request['items'] : [];

        if (!$customerId) {
            return new WP_Error('pwt_customer_required', __('Customer is required.', 'wildtours-plugin'));
        }
        if (!$items) {
            return new WP_Error('pwt_items_required', __('At least one booking item is required.', 'wildtours-plugin'));
        }

        $wpdb->query('START TRANSACTION');

        try {
            $travelStart = null;
            $travelEnd = null;
            $prepared = [];
            $total = 0.0;

            foreach ($items as $item) {
                $itemType = sanitize_key((string)($item['item_type'] ?? ''));
                $itemId = absint($item['item_id'] ?? 0);
                $date = sanitize_text_field((string)($item['service_date'] ?? ''));
                $start = sanitize_text_field((string)($item['start_date'] ?? $date));
                $end = sanitize_text_field((string)($item['end_date'] ?? $date));
                $quantity = max(1, (int)($item['quantity'] ?? 1));

                if (!$itemType || !$itemId || !$date) {
                    throw new \RuntimeException(__('Invalid booking item.', 'wildtours-plugin'));
                }

                $availability = $this->availability->check($itemId, $itemType, $date, $quantity);
                if (!$availability['available']) {
                    throw new \RuntimeException(sprintf(
                        __('%s is not available for the requested date/quantity.', 'wildtours-plugin'),
                        ucwords(str_replace('_', ' ', $itemType))
                    ));
                }

                $quote = $this->pricing->quote($itemType, $itemId, $date, $quantity);
                $unitPrice = (float)($quote['unit_price'] ?? $quote['price'] ?? 0);
                $subtotal = (float)($quote['total'] ?? ($unitPrice * $quantity));

                $prepared[] = compact(
                    'itemType','itemId','date','start','end','quantity','unitPrice','subtotal'
                );
                $total += $subtotal;

                $travelStart = $travelStart === null || $start < $travelStart ? $start : $travelStart;
                $travelEnd = $travelEnd === null || $end > $travelEnd ? $end : $travelEnd;
            }

            $bookingId = $this->bookings->create([
                'customer_id' => $customerId,
                'travel_start' => $travelStart,
                'travel_end' => $travelEnd,
                'total' => $total,
                'currency' => $currency,
                'status' => 'pending',
            ]);

            if (!$bookingId) {
                throw new \RuntimeException(__('Unable to create booking.', 'wildtours-plugin'));
            }

            foreach ($prepared as $item) {
                $this->items->create([
                    'booking_id' => $bookingId,
                    'item_type' => $item['itemType'],
                    'item_id' => $item['itemId'],
                    'service_date' => $item['date'],
                    'start_date' => $item['start'],
                    'end_date' => $item['end'],
                    'quantity' => $item['quantity'],
                    'unit_price' => $item['unitPrice'],
                    'subtotal' => $item['subtotal'],
                    'currency' => $currency,
                ]);
            }

            $wpdb->query('COMMIT');
            return $bookingId;
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('pwt_booking_failed', $e->getMessage());
        }
    }

    public function confirm(int $bookingId): bool|WP_Error
    {
        $booking = $this->bookings->find($bookingId);
        if (!$booking) {
            return new WP_Error('pwt_booking_not_found', __('Booking not found.', 'wildtours-plugin'));
        }

        if (!in_array($booking['status'], ['pending','held','payment_pending'], true)) {
            return $booking['status'] === 'confirmed';
        }

        $items = $this->items->byBooking($bookingId);
        foreach ($items as $item) {
            if (!$this->availability->reserve(
                (int)$item['item_id'],
                (string)$item['item_type'],
                (string)$item['service_date'],
                (int)$item['quantity']
            )) {
                return new WP_Error('pwt_inventory_unavailable', __('Inventory is no longer available.', 'wildtours-plugin'));
            }
        }

        return $this->bookings->updateStatus($bookingId, 'confirmed');
    }

    public function cancel(int $bookingId): bool|WP_Error
    {
        $booking = $this->bookings->find($bookingId);
        if (!$booking) {
            return new WP_Error('pwt_booking_not_found', __('Booking not found.', 'wildtours-plugin'));
        }

        if (in_array($booking['status'], ['confirmed','paid'], true)) {
            foreach ($this->items->byBooking($bookingId) as $item) {
                $this->availability->release(
                    (int)$item['item_id'],
                    (string)$item['item_type'],
                    (string)$item['service_date'],
                    (int)$item['quantity']
                );
            }
        }

        return $this->bookings->updateStatus($bookingId, 'cancelled');
    }
}
