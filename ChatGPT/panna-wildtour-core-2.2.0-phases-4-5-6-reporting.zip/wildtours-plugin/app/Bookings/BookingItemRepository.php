<?php
declare(strict_types=1);
namespace PWT\Bookings;
defined('ABSPATH') || exit;

use PWT\Core\Database\Schema;

final class BookingItemRepository
{
    public function create(array $data): int
    {
        global $wpdb;
        $table = Schema::tables()['booking_items'];
        $row = [
            'booking_id' => absint($data['booking_id'] ?? 0),
            'item_type' => sanitize_key((string)($data['item_type'] ?? '')),
            'item_id' => absint($data['item_id'] ?? 0),
            'service_date' => sanitize_text_field((string)($data['service_date'] ?? '')) ?: null,
            'start_date' => sanitize_text_field((string)($data['start_date'] ?? '')) ?: null,
            'end_date' => sanitize_text_field((string)($data['end_date'] ?? '')) ?: null,
            'quantity' => max(1, (int)($data['quantity'] ?? 1)),
            'unit_price' => max(0, (float)($data['unit_price'] ?? 0)),
            'subtotal' => max(0, (float)($data['subtotal'] ?? 0)),
            'currency' => strtoupper(sanitize_text_field((string)($data['currency'] ?? 'INR'))),
            'meta' => wp_json_encode(is_array($data['meta'] ?? null) ? $data['meta'] : []),
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ];
        $wpdb->insert($table, $row);
        return (int)$wpdb->insert_id;
    }

    public function byBooking(int $bookingId): array
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pwt_booking_items WHERE booking_id=%d ORDER BY id ASC",
            $bookingId
        ), ARRAY_A) ?: [];
    }

    public function deleteByBooking(int $bookingId): int
    {
        global $wpdb;
        return (int)$wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}pwt_booking_items WHERE booking_id=%d",
            $bookingId
        ));
    }
}
