<?php

declare(strict_types=1);

namespace PWT\Core;

defined('ABSPATH') || exit;

use PWT\REST\BookingRestServiceProvider;
use PWT\Reporting\ReportingServiceProvider;
use PWT\Payments\PaymentServiceProvider;
use PWT\Availability\InventoryServiceProvider;
use PWT\Admin\AdminServiceProvider;
use PWT\Analytics\AnalyticsServiceProvider;
use PWT\API\ApiServiceProvider;
use PWT\Bookings\BookingServiceProvider;
use PWT\Frontend\FrontendServiceProvider;
use PWT\Integrations\IntegrationServiceProvider;
use PWT\PostTypes\PostTypeServiceProvider;
use PWT\SCF\SCFServiceProvider;
use PWT\Taxonomies\TaxonomyServiceProvider;
use PWT\Widgets\WidgetServiceProvider;
use PWT\Core\Paths;
use PWT\Core\Database\DatabaseServiceProvider;
use PWT\Architecture\ArchitectureServiceProvider;
use PWT\Services\ServiceServiceProvider;
use PWT\Customers\CustomerServiceProvider;
use PWT\Pricing\PricingServiceProvider;
use PWT\Admin\OperationsServiceProvider;

/**
 * Plugin application.
 */
final class Application
{
    /**
     * @var array<class-string<ServiceProvider>>
     */
    private const PROVIDERS = [
        DatabaseServiceProvider::class,
        ArchitectureServiceProvider::class,
        ServiceServiceProvider::class,
        CustomerServiceProvider::class,
        PricingServiceProvider::class,
        PostTypeServiceProvider::class,
        TaxonomyServiceProvider::class,
        SCFServiceProvider::class,
        BookingServiceProvider::class,
        FrontendServiceProvider::class,
        ApiServiceProvider::class,
        WidgetServiceProvider::class,
        AnalyticsServiceProvider::class,
        AdminServiceProvider::class,
        OperationsServiceProvider::class,
        IntegrationServiceProvider::class,
    ];

    private Container $container;

    public function __construct()
    {
        $this->container = new Container();
    }

    public function boot(): void
    {
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function init(): void
    {
        $this->loadTextDomain();

        foreach (self::PROVIDERS as $provider) {
            $this->container->register($provider);
        }

        $this->container->boot();
    }

    private function loadTextDomain(): void
    {
        load_plugin_textdomain(
            'wildtours-plugin',
            false,
            dirname(plugin_basename(PWT_PLUGIN_FILE)) . '/languages'
        );
    }
}