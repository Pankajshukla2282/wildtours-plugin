<?php
declare(strict_types=1);
namespace PWT\Availability;
defined('ABSPATH') || exit;
use PWT\Core\Database\Schema;

final class AvailabilityRepository
{
    public function set(int $resourceId, string $resourceType, string $date, int $capacity, int $reserved = 0, int $blocked = 0, string $status = 'open'): bool
    {
        global $wpdb;
        $table = Schema::tables()['availability'];
        return false !== $wpdb->replace($table, [
            'resource_type' => sanitize_key($resourceType),
            'resource_id' => $resourceId,
            'service_date' => sanitize_text_field($date),
            'capacity' => max(0, $capacity),
            'reserved' => max(0, $reserved),
            'blocked' => max(0, $blocked),
            'status' => sanitize_key($status),
        ]);
    }

    public function get(int $resourceId, string $resourceType, string $date): array
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . Schema::tables()['availability'] . " WHERE resource_type=%s AND resource_id=%d AND service_date=%s LIMIT 1",
            sanitize_key($resourceType), $resourceId, $date
        ), ARRAY_A);
        return is_array($row) ? $row : [];
    }
}
