<?php
declare(strict_types=1);
namespace PWT\Payments;
defined('ABSPATH') || exit;
use PWT\Core\Database\Schema;

final class PaymentRepository
{
    public function create(int $bookingId, array $data): int
    {
        global $wpdb;
        $now = current_time('mysql');
        $wpdb->insert(Schema::tables()['payments'], [
            'booking_id' => $bookingId,
            'gateway' => sanitize_key((string)($data['gateway'] ?? 'manual')),
            'transaction_id' => sanitize_text_field((string)($data['transaction_id'] ?? '')),
            'status' => sanitize_key((string)($data['status'] ?? 'pending')),
            'amount' => (float)($data['amount'] ?? 0),
            'currency' => strtoupper(sanitize_text_field((string)($data['currency'] ?? 'INR'))),
            'reference' => sanitize_text_field((string)($data['reference'] ?? '')),
            'paid_at' => $data['paid_at'] ?? null,
            'meta' => wp_json_encode($data['meta'] ?? []),
            'created_at' => $now,
            'updated_at' => $now,
        ]);
        return (int)$wpdb->insert_id;
    }
}
