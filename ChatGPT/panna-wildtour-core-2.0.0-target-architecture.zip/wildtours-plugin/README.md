# Panna Wild Tour Core 2.0

Core WordPress plugin for the Panna Wild Tour travel, safari, accommodation, restaurant and local-trip business.

## Responsibilities

- Business/content post types and taxonomies
- SCF field groups
- Customers
- Bookings and booking items
- Availability/capacity
- Pricing/rates
- Inventory checks
- Payments
- REST API
- Integrations

Themes remain presentation-only.

## Compatibility

Existing `pwt_booking` posts are retained. The new normalized booking tables are additive and linked to legacy booking records.

See `docs/ARCHITECTURE.md` for the target architecture and migration roadmap.
