# Panna Wild Tour Core 2.0 Architecture

## Layers

- **Content**: Packages, Safaris, Destinations, Resorts, Vehicles, Restaurants, Local Trips, Reviews, FAQs.
- **Customers**: normalized customer records in `pwt_customers`.
- **Bookings**: normalized bookings and booking items in custom tables; the existing `pwt_booking` CPT remains as a compatibility/admin record.
- **Availability**: date/resource capacity in `pwt_availability`.
- **Pricing**: date/season/quantity-aware rates in `pwt_rates`.
- **Inventory**: reservation checks through AvailabilityService.
- **Payments**: normalized transactions in `pwt_payments`; existing gateway classes remain usable.
- **Integrations**: REST, SCF, Fluent integrations and future gateway adapters.
- **Presentation**: remains in the WildTours base/child themes.

## Resource model

Resources use stable identifiers:

- `package`
- `safari`
- `resort`
- `room` (future inventory subtype)
- `restaurant`
- `local_trip`
- `vehicle`

The availability and pricing tables deliberately use `resource_type + resource_id` so new resource types can be introduced without a schema migration.

## Booking model

A booking has:

- one customer
- many booking items
- totals
- travel dates
- lifecycle status
- payments

The existing booking CPT is not removed. New normalized records are linked by `_pwt_normalized_booking_id`.

## Next implementation phases

1. Room/unit inventory and hotel room types.
2. Safari seat/vehicle capacity.
3. Seasonal pricing and package component pricing.
4. Booking hold/expiry and atomic inventory reservation.
5. Payment webhook verification and refunds.
6. Customer portal and authenticated booking access.
7. Notifications and operational dashboards.
8. Reporting/analytics and exports.

## API

Public read-only endpoints:

- `GET /wp-json/pwt/v1/availability`
- `GET /wp-json/pwt/v1/quote`

Booking creation and payment mutation endpoints should require nonce/authentication and idempotency keys before being exposed publicly.
